import csv
import unittest
from time import sleep

from parameterized import parameterized

from chapter01.v3.base.get_driver import GetDriver
from chapter01.v3.page.PageLogin import PageLogin
from chapter01.v3.page.AddPage import addpage
#参数化
def get_data():
    return[("12","001","001","shtd")]
class TestLogin(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.driver=GetDriver().get_driver()
        cls.login=PageLogin(cls.driver)
        cls.login.page_click_login_btn()
        cls.add = addpage(cls.driver)
        #cls.add.brand_btn_click()
    @classmethod
    def tearDownClass(cls) -> None:
        GetDriver().quit_driver()
    @parameterized.expand(get_data())
    def test_login(self,id,username,pwd,vericode):
        self.login.page_login(id,username,pwd,vericode)
        self.add.brand_btn_click()
        with open("brand_add.csv",encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in reader:
                self.add.brand_add(row[0], row[1])
                self.add.brand_add_btn()